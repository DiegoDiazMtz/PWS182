@extends('layouts.plantilla')

@section('titulo','Inicio')

@section('contenido')

    <h1 class="display-1 text-center text-danger mt-5"> HOME </h1>

@endsection
    
