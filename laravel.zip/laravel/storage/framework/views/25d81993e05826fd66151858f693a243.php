<?php $__env->startSection('titulo','Inicio'); ?>

<?php $__env->startSection('contenido'); ?>

    <h1 class="display-1 text-center text-danger mt-5"> HOME </h1>

<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelXphp\PWS182\practica3\resources\views/welcome.blade.php ENDPATH**/ ?>